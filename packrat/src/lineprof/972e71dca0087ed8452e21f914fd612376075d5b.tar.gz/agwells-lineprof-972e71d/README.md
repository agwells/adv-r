# lineprof

lineprof is now deprecated in favour of [profvis](https://github.com/rstudio/profvis). Please use that instead.
