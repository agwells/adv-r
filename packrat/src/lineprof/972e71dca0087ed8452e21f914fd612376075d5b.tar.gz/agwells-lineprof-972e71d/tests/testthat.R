library(testthat)
library(lineprof)

test_check("lineprof")
