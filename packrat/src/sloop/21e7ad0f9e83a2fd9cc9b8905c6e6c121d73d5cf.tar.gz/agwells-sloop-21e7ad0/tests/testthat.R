library(testthat)
library(S3)

test_check("S3")
