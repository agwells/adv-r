# DEPRECATED

Please use <http://github.com/rstudio/bookdown/issues> instead
